# sound game part 1 : moving parts and looping sounds

finished sketch: https://socalledsound.github.io/sound-game-1-starter/
